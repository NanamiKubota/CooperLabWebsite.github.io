---
title: Microbial Genomics Sequencing
image: /images/nextseq.png
---
We offer high-throughput sequencing services on Illumina's NextSeq 500 platform. In addition to this, we offer custom bioinformatic services to suit any of your microbial genetics needs. Click [here]({{site.baseurl}}/sequencing.html) to learn more about the services we offer.