---
title: EvolvingSTEM
image: /images/class.jpg
---
The best way to learn and encourage excitement in young people about science is through a hands-on approach. The EvolvingSTEM program provides a ready-to-implement hands-on curriculum for high schoolers to learn evolution, microbiology, basic biotechnology, and get excited about STEM research careers. 
