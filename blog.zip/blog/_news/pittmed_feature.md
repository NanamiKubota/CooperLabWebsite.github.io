---
title: PITTMED Feature
image: "/images/pittmed_feature.jpg"
---
The Cooper Lab would like to extend a thank you to Elaine Vitone who wrote a feature, Untangling Darwin, focused on the lab’s research in the University of Pittsburgh’s PITTMED magazine. Vitone’s feature can be accessed on PITTMED’s webpage or as a PDF.