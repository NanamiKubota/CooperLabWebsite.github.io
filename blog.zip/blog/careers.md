---
layout: page
header: pgh-header
title: Careers
---
Current Opportunities:

We welcome inquiries from creative people interested in evolution, microbiology, genomics, bioinformatics, and scientific outreach.

Please send your CV to [Vaughn](mailto:vaughn.cooper@pitt.edu).

We, in collaboration with the [Bomberger lab](http://www.mmg.pitt.edu/lab/bomberger-lab), seek a motivated colleague who shares our interest in defining evolutionary dynamics of bacterial populations during polymicrobial infections of the cystic fibrosis airway. Click [here](http://postdocjobs.hs.pitt.edu/ViewPost.aspx?q=963) for more details.