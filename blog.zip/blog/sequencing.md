---
layout: page
header: dna-header
title: The Microbial Evolution Sequencing Hub
subtitle: (MESH)
---

## We offer sequencing services on an Illumina NextSeq 500 sequencer as well as bioinformatics analyses.

## Want to learn more? [Email Dr. Cooper and Dan Snyder](mailto:vaughn.cooper@pitt.edu?subject=Sequencing%20Services&cc=snyde236@gmail.com)
